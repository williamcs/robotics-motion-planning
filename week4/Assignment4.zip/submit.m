%% Script to test student's implementation of Module 4
disp('Evaluating...');
evaluate();