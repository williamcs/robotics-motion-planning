function distance = findSqDistance(pt1,pt2)

distance = sqrt((pt1(1)-pt2(1))^2+(pt1(2)-pt2(2))^2);

end