%% 


function submit()

disp('Evaluating ... ');
evaluate();


end
